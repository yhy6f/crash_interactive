
#####What is this?
A dead-simple jQuery slideshow example that uses buttons to store class names for teh elements we want to hide and show on click.